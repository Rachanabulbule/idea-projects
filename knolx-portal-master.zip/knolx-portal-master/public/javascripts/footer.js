$(function () {

    $("#current-year").html(moment().format('YYYY'));

});
