$(document).ready(function () {
    $('#manageSubmenu').collapse('toggle');
});
