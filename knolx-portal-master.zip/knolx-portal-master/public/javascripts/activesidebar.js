 if (localStorage.hasActiveClass === "yes") {
        $('#sidebar').addClass("active");
    } else {
        $('#sidebar').addClass("");
}
